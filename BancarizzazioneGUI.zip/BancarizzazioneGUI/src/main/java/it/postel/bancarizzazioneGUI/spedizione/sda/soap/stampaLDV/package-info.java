@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.service.spedizionews.sda.it/")
package it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV;
