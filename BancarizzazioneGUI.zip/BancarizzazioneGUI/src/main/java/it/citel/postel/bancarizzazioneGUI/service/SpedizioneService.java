package it.citel.postel.bancarizzazioneGUI.service;

import java.io.IOException;
import java.net.MalformedURLException;

import it.citel.postel.commonLib.rest.model.Request;
import it.citel.postel.commonLib.rest.model.RequestGetDettagliSpedizione;
import it.citel.postel.commonLib.rest.model.RequestPersistGetLDVFromWSStampaSDA;
import it.citel.postel.commonLib.rest.model.RequestSpedizione;
import it.citel.postel.commonLib.rest.model.Response;

public interface SpedizioneService {
	
//    public Response<?>  ricercaSpedizione(Request<RequestSpedizioneCustom>  request) throws MalformedURLException, IOException, Exception ;
//	public Response<?>  loadListIdentificativoPA() throws MalformedURLException, IOException, Exception ;
//	public Response<?>  loadListTipologiaIstanzaPA() throws MalformedURLException, IOException, Exception ;
//	public Response<?>  loadListVettori() throws MalformedURLException, IOException, Exception ;
//	public Response<?>  loadVettoreDefault(Request<SpedizioneObj>  request) throws MalformedURLException, IOException, Exception ;
//	public Response<?>  loadListScatole(Request<RequestScatolaCustom>  request) throws MalformedURLException, IOException, Exception ;
//	public Response<?>  stampaLdvSDA(Request<RequestSpedizione>  request) throws MalformedURLException, IOException, Exception ;
//	public ResponseEntity<byte[]>  getPdfLdV() throws MalformedURLException, IOException, Exception ;
//	public Response<?>  checkScatolaPerSpedizione(Request<ScatolaObj>  request) throws MalformedURLException, IOException, Exception ;
//	public Response<?>  checkScatolaIsSpedita(Request<ScatolaObj>  request) throws MalformedURLException, IOException, Exception ;
//	public Response<?>  dettScatolaFromSpedizione(Request<SpedizioneObj>  request) throws MalformedURLException, IOException, Exception ;
	
    
//    Response<?>  getDettaglioSpedizioneSDA(Request<RequestGetDettagliSpedizione> request) throws MalformedURLException, IOException, Exception ;
    
//	Response<?>  persistStampaLDV(Request<RequestPersistGetLDVFromWSStampaSDA> request) throws MalformedURLException, IOException, Exception ;
//	Response<?> stampaLdvSDA(Request<RequestSpedizione> request) throws MalformedURLException, IOException, Exception;

    
    
	
	
}
