import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import it.citel.postel.bancarizzazioneGUI.util.UtilWS;
import it.citel.postel.commonLib.objects.spedizione.sda.AnagraficaSpedizioneObj;
import it.citel.postel.commonLib.objects.spedizione.sda.ColliSpedizioneObj;
import it.citel.postel.commonLib.objects.spedizione.sda.DatiGeneraliSpedizioneObj;
import it.citel.postel.commonLib.objects.spedizione.sda.DatiSpedizioneObj;
import it.citel.postel.commonLib.objects.spedizione.sda.Ldv;
import it.citel.postel.commonLib.objects.spedizione.sda.SezioneColliSpedizioneObj;
import it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.DoIt;
import it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.ObjectFactory;

public class Main {

	public static void main(String[] args) throws Exception {
		Ldv ldv =  new Ldv() ;
		
		DatiSpedizioneObj datiSpedizione = new DatiSpedizioneObj() ;
		datiSpedizione.setCodiceServizio( "S09" );
		
		DatiGeneraliSpedizioneObj datiGenerali = new DatiGeneraliSpedizioneObj() ;
		datiGenerali.setContenuto("Pallet");
		datiGenerali.setDataSpedizione( "20/07/2021" );
		datiGenerali.setNumRifInterno( "9" );
		datiSpedizione.setDatiGenerali( datiGenerali );
		
		ColliSpedizioneObj collo = new ColliSpedizioneObj() ;
		List<ColliSpedizioneObj> listColli = new ArrayList<>() ;
		collo.setAltezza( new BigDecimal(50) );
		collo.setLarghezza( new BigDecimal(50) );
		collo.setPeso( new BigDecimal(25) );
		collo.setProfondita( new BigDecimal(30) );
		listColli.add(collo) ;
		SezioneColliSpedizioneObj sezioneColli = new SezioneColliSpedizioneObj() ;
		sezioneColli.setColli( listColli ) ;
		datiSpedizione.setSezioneColli( sezioneColli ) ;
		
		ldv.setDatiSpedizione( datiSpedizione ) ;
		
		AnagraficaSpedizioneObj destinatario = new AnagraficaSpedizioneObj() ;
		destinatario.setTipoAnagrafica( "S" );
		ldv.setDestinatario( destinatario ) ;
		
		AnagraficaSpedizioneObj mittente = new AnagraficaSpedizioneObj() ;
		mittente.setCap( "00071" );
		mittente.setCodNazione( "ITA" );
		mittente.setEmail( "eduardo.spagnolo@postel.it" );
		mittente.setIndirizzo( "Via Campobello, 43" );
		mittente.setIntestatario( "Postel S.P.A." );
		mittente.setLocalita( "Pomezia" );
		mittente.setProvincia( "RM" );
		mittente.setReferente( "Eduardo Spagnolo" );
		mittente.setTelefono( "0691601561" );
		mittente.setTipoAnagrafica( "S" );
		ldv.setMittente( mittente ) ;
		
		sendRequestStampaSDA( createSoapMessageRequestWS( setRequestWSStampaLDV( ldv ) , "file:C:\\Users\\emilio.scarpellino\\Desktop\\Postel\\BancarizzazioneADE\\Workspaces\\TRUNK\\BancarizzazioneADEMainPOM\\BancarizzazioneGUI\\src\\main\\resources\\wsdl\\sda" ) ) ;
	}

	private static SOAPMessage sendRequestStampaSDA(SOAPMessage requestMsg) {
		String endpoint = "https://collaudo-ws.sda.it/SPEDIZIONE-WS-WEB/SpedizioneActionService" ;
		System.out.println("soapUrl: " + endpoint);
		SOAPMessage response = null;
		SOAPConnection connection = null;
		Socket socket = null;

		String proxyHost = "172.30.245.200";
		int proxyPort = 9090 ;
		
//		String proxyHost = "0.0.0.0";
//		int proxyPort = 9090 ;

//		String proxyHost = System.getProperty("http.proxyHost") ;
//		String proxyPort = System.getProperty("http.proxyPort") ;
//	
//		System.setProperty("http.proxyHost"				, "rm-mswg-vip.postel.it"	); 
//		System.setProperty("http.proxyPort"				, "9090"					); 
//		System.setProperty("java.net.useSystemProxies"	, "true"					);

		try {
			System.out.println("request soap : " + requestMsg.toString());
			SOAPConnectionFactory soapFactory = SOAPConnectionFactory.newInstance();
			connection = soapFactory.createConnection();
			
//			System.out.println("Open socket on host: " + proxyHost + " and port: " + proxyPort);
//
//			socket = new Socket();
//			SocketAddress address = new InetSocketAddress(proxyHost, proxyPort);
//
//			System.out.println( "Opening Socket" ) ;
//			socket.connect(address, 100000);
//			System.out.println( "Socket open" ) ;
//
//			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(socket.getInetAddress(), proxyPort));
//			URL url = new URL(endpoint);
//
//			System.out.println("Proxy created on address:" + proxy.address());
//
//			HttpURLConnection uc = (HttpURLConnection) url.openConnection(proxy);
			
			response = connection.call(requestMsg , endpoint);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception : " + e.getMessage());
		} finally {
//			System.setProperty("http.proxyHost"	, proxyHost	!= null ? proxyHost	: ""); 
//			System.setProperty("http.proxyPort"	, proxyPort	!= null ? proxyPort	: "");
			try {
				connection.close();
				socket.close();
			} catch (Exception e) {
				System.out.println("Problems closing connection");
			}
		}

		return response;
	}
	
static SOAPMessage createSoapMessageRequestWS(it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.DoIt doItRequest, String url_wsdl_location) throws Exception {
		
		System.out.println("INIZIO - Web Service Stampa per servizio Extralarge SDA...");
//		SpedizioneActionService spedizioneActionService = new SpedizioneActionService();
		
		SOAPConnection soapConn = null;
//		String usernameWS = "DEM210175";
//		String passwordWS = "Gennaio10!";
//		String endpoint = "https://collaudo-ws.sda.it:443/STAMPA-LDV" ;//devRestConstants.SDA_SPEDIZIONE_STAMPA_SOAP_ENDPOINT;
//		String wsBindingId ="http://schemas.xmlsoap.org/wsdl/soap/http";

		
//		spedizioneActionService.setUrl_wsdl_location(url_wsdl_location);
		
//		DoItResponse doItResponse = null;
//		QName serviceName = spedizioneActionService.getServiceName();
//		QName SERVICE = spedizioneActionService.SERVICE;
//		QName portName = spedizioneActionService.SpedizioneActionPort;
		
//		javax.xml.ws.Service service = javax.xml.ws.Service.create(SERVICE);
//		
//		service.addPort(portName, wsBindingId, endpoint);
		JAXBContext context = JAXBContext.newInstance(DoIt.class);

		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();

		SOAPPart soapPart = soapMessage.getSOAPPart();

		SOAPEnvelope envelope = soapPart.getEnvelope();
		SOAPHeader soapHeader = soapMessage.getSOAPHeader();

		envelope.setPrefix("soapenv");
		envelope.removeNamespaceDeclaration("SOAP-ENV");
//	    envelope.addNamespaceDeclaration("soap", serverURI);
//	    envelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");

		soapHeader.setPrefix("soapenv");

//		String authorization = new sun.misc.BASE64Encoder().encode((usernameWS + ":" + passwordWS).getBytes());
//		String authorization = "" ;
//		String soapAction = "";
		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.setHeader("Content-Type", "text/xml; charset=utf-8");
//		headers.addHeader("Authorization", "Basic " + authorization);
//		headers.addHeader("SOAPAction", soapAction);

		SOAPBody body = soapMessage.getSOAPBody();
		body.removeNamespaceDeclaration("SOAP-ENV");
		body.setPrefix("soapenv");

		Marshaller marshaller = context.createMarshaller();
//		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		marshaller.marshal(doItRequest, body);

		soapMessage.saveChanges();

//		soapMessage.writeTo(System.out);
		System.out.println("Request: " + UtilWS.getSoapMessageAsString(soapMessage));
		System.out.println("Fine Creazione soap message request.");
		return soapMessage;
	}

public static it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.DoIt setRequestWSStampaLDV(Ldv ldvForm) {
	
//	log.debug("Convert request into object for request soap message");
	// Crea JAXB request object
	ObjectFactory objFactory = new ObjectFactory();
	
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.DoIt doItWS = objFactory.createDoIt();
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.Ldv ldvWS = objFactory.createLdv();
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.DatiSpedizione datiSpedizioneWS = objFactory.createDatiSpedizione();
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.Accessori accessoriWS = objFactory.createAccessori();
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.Colli colliWS = objFactory.createColli();
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.DoIt.Arg0 arg0WS = objFactory.createDoItArg0();
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.SezioneColli sezioneColliWS = objFactory.createSezioneColli();
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.Mittente mittenteWS = objFactory.createMittente();
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.Destinatario destinatarioWS = objFactory.createDestinatario();
	
	it.citel.postel.commonLib.objects.spedizione.sda.DatiSpedizioneObj datiSpedizioneForm = ldvForm.getDatiSpedizione();
	datiSpedizioneWS.setAccessori(accessoriWS);//
	datiSpedizioneWS.setCodiceServizio(datiSpedizioneForm.getCodiceServizio());
	
	it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.DatiGenerali datiGeneraliWS = objFactory.createDatiGenerali();
	
	datiGeneraliWS.setCodContenuto(datiSpedizioneForm.getDatiGenerali().getContenuto());
	datiGeneraliWS.setDataSpedizione(datiSpedizioneForm.getDatiGenerali().getDataSpedizione());
	datiGeneraliWS.setNote(datiSpedizioneForm.getDatiGenerali().getNote());
	datiGeneraliWS.setNumRifInterno(datiSpedizioneForm.getDatiGenerali().getNumRifInterno());
	datiSpedizioneWS.setDatiGenerali(datiGeneraliWS);
	
	colliWS.setAltezza(datiSpedizioneForm.getSezioneColli().getColli().get(0).getAltezza());
	colliWS.setLarghezza(datiSpedizioneForm.getSezioneColli().getColli().get(0).getLarghezza());
	colliWS.setPeso(datiSpedizioneForm.getSezioneColli().getColli().get(0).getPeso().toString());
	colliWS.setProfondita(datiSpedizioneForm.getSezioneColli().getColli().get(0).getProfondita());
	
	List<it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.Colli> colliList = new ArrayList<it.postel.bancarizzazioneGUI.spedizione.sda.soap.stampaLDV.Colli>();
	colliList.add(colliWS);
	sezioneColliWS.setColli(colliList);;
	datiSpedizioneWS.setSezioneColli(sezioneColliWS);
	
	ldvWS.setDatiSpedizione(datiSpedizioneWS);
	
	AnagraficaSpedizioneObj mittente = ldvForm.getMittente();
	
	mittenteWS.setCap(mittente.getCap());
	mittenteWS.setCodNazione(mittente.getCodNazione());
//	mittenteWS.setCodStato(mittente.);
	mittenteWS.setEmail(mittente.getEmail());
	mittenteWS.setIdentificativoFiscale(mittente.getIdentificativoFiscale());
	mittenteWS.setIndirizzo(mittente.getIndirizzo());
	mittenteWS.setIntestatario(mittente.getIntestatario());
	mittenteWS.setLocalita(mittente.getLocalita());
	mittenteWS.setProvincia(mittente.getProvincia());
	mittenteWS.setReferente(mittente.getReferente());
	mittenteWS.setTelefono(mittente.getTelefono());
	mittenteWS.setTipoAnagrafica(mittente.getTipoAnagrafica());
	
	ldvWS.setMittente(mittenteWS);
	
	AnagraficaSpedizioneObj destinatario = ldvForm.getDestinatario();
	
	destinatarioWS.setCap(destinatario.getCap());
	destinatarioWS.setCodNazione(destinatario.getCodNazione());
//	destinatarioWS.setCodStato(destinatario.);
	destinatarioWS.setEmail(destinatario.getEmail());
	destinatarioWS.setIdentificativoFiscale(destinatario.getIdentificativoFiscale());
	destinatarioWS.setIndirizzo(destinatario.getIndirizzo());
	destinatarioWS.setIntestatario(destinatario.getIntestatario());
	destinatarioWS.setLocalita(destinatario.getLocalita());
	destinatarioWS.setProvincia(destinatario.getProvincia());
	destinatarioWS.setReferente(destinatario.getReferente());
	destinatarioWS.setTelefono(destinatario.getTelefono());
	destinatarioWS.setTipoAnagrafica(destinatario.getTipoAnagrafica());
	
	ldvWS.setDestinatario(destinatarioWS);
	arg0WS.setFormatoStampa("A4");
	arg0WS.setLdv(ldvWS);;
	doItWS.setArg0(arg0WS);
	
	
//	datiSpedizioneWS.set
//	datiSpedizioneWS.set
//	datiSpedizioneWS.set
//	datiSpedizioneWS.set
	return doItWS;
	
}

}
