$( document ).ajaxError(function(event, xhr, settings, thrownError ) {
	  if(xhr.status === 403)
		  window.location.reload();
});

var timer = null;
var timerGlobalInMillesecond = 60 * 5000;
var timerGlobalInMinute = "5:00";

$(document).ready(function() {
	
	loadLstClienti();
	updateTableCarico();
	
	$("#btn-cerca").click(function() {
		updateTableCarico();	
	});
	
var target = document.getElementById('spinnerContainer');
var spinner;
var spinning = false;

if($('input[name="descprofilo"]').val()!="Supervisore"){
//detailsMonitor();
}else{
//	loadLstCentriDemat('centroDemat');
}



function toggleSpin(){
    spinning ? spinner.stop() : spinner = new Spinner(opts).spin(target);  
    spinning = !spinning;
}	
	
//$("#centroDemat").change(function() {
//	updateTableSla();
//	updateTableCarico();
//	detailsMonitor();
////	timer.reset(60 * 5000);
//});	


	
	



function getCentroDemat(){
	var centroDemat;
	$("#centroDemat").val()==null ? centroDemat=$('input[name="centrodemat"]').val() : centroDemat=$("#centroDemat").val();
	return centroDemat;
}


function updateTableCarico(){	
//	timedRefresh();
	console.log('monitorCarico start');		
//	calculateTimeRemaining(this.timer)
	resetValue();
	var centroDemat = getCentroDemat();
	var username = $('input[name="user"]').val();
	var clienteID = $('#comboClienti').children("option:selected").val();
	var tipoMonTypeId = $('input[name="tipoMonTypeId"]').val();
	var uri_carico = contextPath + "/monitoraggio/getMonitorSLA?"; 	
	
	
	$.ajax({
		type : 'POST',
		url: uri_carico,	
        dataType: 'json',
        data: { 
        		"clienteID": clienteID, 
        		"centroDematID": centroDemat, 
        		"username": username,
        		"tipoMonTypeId":tipoMonTypeId
        	   },
		success : function(result) {
			if(result.status){
				
				//table show
				var listaValue = result.data.value;
				var intestazioneColonna = result.data.intestazioneColonna;
				var tableArray = result.data;
					
				$("table").bootstrapTable('destroy');
			    $("table thead tr").html('');
			    
			    var valueTable = 1;
			    //per ogni tabella
			    tableArray.forEach(function(element) {
			    	  var nameTable = "table_"+ valueTable;
			    	  var tag_append = "<div class='row'><h3 class='col-lg-12'>"+element.titoloMonitor +"</h3></div><div class='row'><table id=\"" + nameTable +"\" data-toggle=\"table\" class=\"table table-hover\"><thead><tr></tr></thead></table></div>";
			    	  $("#appendBody").append(tag_append);
			    	  var intColonnaObj = element.intestazioneColonna;
			    	  intColonnaObj.sort(dynamicSort("sequenceColumn"));
			    	  $.each(intColonnaObj, function(index, value) {
					    	var colonna = value.colonna;
					    	var label = value.label;
					    	var width = 'auto';
					    	if(value.width != '') width = value.width + '%';
					    	
					    	var tr = '<th data-field="'+ colonna +'" title="'+ label +'" width="'+ width +'%" >'+ colonna +'</th>';
					    	$("#"+ nameTable + " thead tr").append(tr);
//					    	console.log("tr : " + tr);
					    	});
			    	  
//			    	   var listData = element
//			    	   alert("id table = " + nameTable);
			    	   $("#"+ nameTable + "").bootstrapTable();
//					    console.log("carico table..");
					   $("#"+ nameTable + "").bootstrapTable('load', {data: element.value});
			    	   
					   if (tipoMonTypeId==2 || tipoMonTypeId==3) {
					    	$("#"+ nameTable + "").on('dbl-click-row.bs.table',confermaSLAEscludereDallElencoModal);
					   }
					    
					    valueTable = valueTable + 1;
			    	});
			    
				console.log("carico table terminata..");
			}else{
				alert("Nessun dato trovato per il cliente " +  $('#comboClienti').children("option:selected").text());
			}
			
		},
		error : function(xhr, status, error, result) {
			console.log('errore!');
			console.log('xhr ', xhr);
			console.log('status ', status);
			console.log('error ', error);
			console.log('result ', result);
			 showErrorMessage(true,error,SUFFIX_MSG);
		}
	});
	
	
	}	


$("#esportaCSV").click(function() {
	console.log('esportaCSV'); 
	$(".bootstrap-table").show(500);	

	console.log('monitorCarico start');		

	var centroDemat = getCentroDemat();
	var username = $('input[name="user"]').val();
	var clienteID = $('#comboClienti').children("option:selected").val();
	var tipoMonTypeId = $('input[name="tipoMonTypeId"]').val();
	var uri_carico = contextPath + "/monitoraggio/getMonitorSLA?"; 
	$.ajax({
		type : 'GET',
		url: uri_carico,	
        dataType: 'json',
        data: { 
	        	"clienteID": clienteID, 
	    		"centroDematID": centroDemat, 
	    		"username": username,
	    		"tipoMonTypeId":tipoMonTypeId
        	   },
		success : function(result) {
		console.log(result );
	
		var checkDataEmpty = result.data[0];
		console.log(checkDataEmpty);
		console.log("sono prima del for");
		
		var arrayCsv = [];
		for (numTabella = 0; numTabella < result.data.length; numTabella++ ){
			csv = "";

			var arrayIntestazioniColonna = result.data[numTabella].intestazioneColonna;
			arrayIntestazioniColonna.sort((a, b) => (a.sequenceColumn > b.sequenceColumn) ? 1 : -1);
			
			for(j = 0; j < arrayIntestazioniColonna.length; j++) {
				if (csv != "")
					csv += ";";
				csv += '"' + arrayIntestazioniColonna[j].colonna.replace("<br>"," ") +  '"';
			}
		
			for(i = 0; i < result.data[numTabella].value.length; i++) {
				row = result.data[numTabella].value[i];
				csvrow = "";
				for(j = 0; j < arrayIntestazioniColonna.length; j++) {
					console.log(arrayIntestazioniColonna[j].colonna);
					if (csvrow != "")
						csvrow += ";";	
					html = $.parseHTML(row[arrayIntestazioniColonna[j].colonna]);
					value = $(html).last().text();
					csvrow += '"' + value +  '"';
				}
				console.log(csvrow);
				csv = csv + '\n' + csvrow;
			}
			
			arrayCsv.push(csv);
		}
		
		var zip = new JSZip();
		for(h=0; h<arrayCsv.length; h++){
			zip.file("Monitor_" + h +".csv", arrayCsv[h]);

		}
		zip.generateAsync({type:"blob"})
		.then(function(content) {
		  
			var downloadLink = document.createElement("a");
	        downloadLink.href = window.URL.createObjectURL(content);
	        downloadLink.download = "monitoraggio_sla.zip";

	        document.body.appendChild(downloadLink);
	        downloadLink.click();
	        document.body.removeChild(downloadLink);
		});
		
	}
				

});

});

//ricerca clienti al caricamento della pagina
function loadLstClienti() {
//	showLoaderLst(true,"Attendere! Caricamento lista clienti in corso...");
	//var url = contextPath + '/' + 'spedizione' + '/getComboClienti';
	var url = contextPath + '/common/getComboClienti';
	$.ajax({
		type : 'GET',
		url : url,
		success : function(data) {
//			$("#comboClienti").empty();
			var lst = data.data;
			console.log("lengt: " +lst.length);
			$("#comboClienti").append("<option value=''> Tutti </option>");
			for (var i = 0; i < lst.length; i++) {
				var obj = lst[i];
				$("#comboClienti").append(
						"<option value=" + obj.value + ">"
								+ obj.descrizione + "</option>");
			}
//			showLoaderLst(false,'');
		},
		error : function(xhr, status, error, result) {
			console.log('errore!');
			console.log('xhr ', xhr);
			console.log('status ', status);
			console.log('error ', error);
			console.log('result ', result);
			$('#danger_msg').text(error);
			$('#div_error_alert').show();
		}
	});
}

function resetValue(){
	
	$("#appendBody").empty();
	$("#appendBody").html('');
	
}

});

function dynamicSort(property) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        /* next line works with strings and numbers, 
         * and you may want to customize it to your needs
         */
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
}

$("#refresh").click(function() {	
//	timer.reset(timerGlobalInMillesecond);
	console.log('refresh');
	updateTableCarico();
});


function Timer(fn, t) {
    var timerObj = setInterval(fn, t);

    this.stop = function() {
        if (timerObj) {
            clearInterval(timerObj);
            timerObj = null;
        }
        return this;
    }

    // start timer using current settings (if it's not already running)
    this.start = function() {
        if (!timerObj) {
            this.stop();
            timerObj = setInterval(fn, t);
        }
        
        return this;
    }

    // start with new interval, stop current interval
    this.reset = function(newT) {
        t = newT;
        return this.stop().start();
    }
}	

//timer refresh page
timer = new Timer(function(timer) {
	updateTableCarico();
//	timedRefresh(timer);
}, timerGlobalInMillesecond);	


function timedRefresh(timer) {

	timer.reset(timerGlobalInMillesecond);
	   var timer2 = timerGlobalInMinute;
	   alert(timer2);
	   timer = setInterval(function() {
		    
		   
		    console.log(timerGlobalInMinute);
		    var timer = timer2.split(':');
		    //by parsing integer, I avoid all extra string processing
		    var minutes = parseInt(timer[0], 10);
		    var seconds = parseInt(timer[1], 10);
		    --seconds;
		    minutes = (seconds < 0) ? --minutes : minutes;
		    if (minutes < 0) clearInterval(interval);
		    seconds = (seconds < 0) ? 59 : seconds;
		    seconds = (seconds < 10) ? '0' + seconds : seconds;
		    //minutes = (minutes < 10) ?  minutes : minutes;
//		    $('#countdown').html("Aggiornamento Monitor: " + minutes + ':' + seconds);
		    timer2 = minutes + ':' + seconds;
		}, 1000);
	};
	
	function sleep(ms) {
		  return new Promise(resolve => setTimeout(resolve, ms));
	}

	function confermaSLAEscludereDallElencoModal(row,$element,field) {
		if ($element.showDetail==1) {
			var idSLA = $element.detailKey01;
			$('#titleModal').text("CONFERMA ESCLUDERE DALL'ELENCO");

			$('#textBodyConfermaModal').text("Sei sicuro di voler contrassegnare questo oggetto come \"da escludere dall\'elenco\"?" +
					"\n(Questa operazione troverà riscontro nel prossimo aggiornamento)");
									
			$("#conferma").attr("onclick", "confermaEscludereDallElenco('" + idSLA + "' );");
			$('#confermaSLAEscludereDallElencoModal').modal('show');
		}
	}

	function confermaEscludereDallElenco(idSLA) {
		var url = contextPath + '/monitoraggio/escludereOggettoDallElenco';
		$.ajax({
			type: 'POST',
		        url: url,	    
		        dataType: 'json',
		        data:  {"idSLA": idSLA},
			success : function(result) {
				if(result.status){
					$('#confermaSLAEscludereDallElencoModal').modal('hide');
				}else{
					alert("Errore richiesta !");
				}
			},
			error : function(xhr, status, error, result) {
				waitingDialog.hide();
				console.log('errore!');
				console.log('xhr ', xhr);
				console.log('status ', status);
				console.log('error ', error);
				console.log('result ', result);
				showErrorMessage(true,error);
			}
		});
	}